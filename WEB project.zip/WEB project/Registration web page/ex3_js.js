
function validation()
		{

			var name=document.forms["form"]["uname"].value;
	    var doorno=document.forms["form"]["dno"].value;
			var vname=document.forms["form"]["vname"].value;
			var dname=document.forms["form"]["dname"].value;
			var pincode=document.forms["form"]["pincode"].value;
			var mail=document.forms["form"]["eid"].value;
			var pass=document.forms["form"]["pass"].value;
			var cpass=document.forms["form"]["cpass"].value;
			var pno=document.forms["form"]["pno"].value;
			var course=document.forms["form"]["course"].value;

      if(name=="" && doorno==""&& vname==""&&dname==""&&pincode==""&&mail==""&&pass==""&&pno=="")
      {
        window.alert("Please Fill the all details..!");
       return false;
      }
      else
      {
      if (name=="" || name==null)
       {
        window.alert("Please Enter a Name");
        return false;
       }
       if (doorno=="" || doorno==null)
       {
        window.alert("Please Enter a Door Number");
        return false;
       }
       if (vname=="" || vname==null)
       {
        window.alert("Please Enter a Village Name");
        return false;
       }
       if (dname=="" || dname==null)
       {
         window.alert("Please Enter a District Name");
         return false;
       }
       if (pincode=="" || pincode==null)
       {
        window.alert("Please Enter a Pincode Number");
        return false;
       }
       else if (pincode.length >6 || pincode.length <6)
       {
        window.alert("Pincode Enter a valid Pincode");
        return false;
       }
       if (mail=="" || mail==null)
       {
        window.alert("Please Enter a Mail ID");
        return false;
       }
        reg =/^\S+@\S+\.\S+$/;
       if (!reg.test(mail))
       {
         window.alert("Please Enter a Valid Mail ID");
         return false;
       }
       if (pass==null || pass=="")
        {
          window.alert("Please Enter a Password");
          return false;
        }   
	if(pass != "" && pass == cpass)
	{
      if(pass.length < 8 && pass.length >13 )
      {
        window.alert("Password must contain at least 8 to 13 characters!");
       return false;
      }
      re = /[0-9]/;
     if(!re.test(pass))
     {
        window.alert("password must contain at least one number (0-9)!");
      return false;
      }
      re = /[a-z]/;
      if(!re.test(pass))
      {
        window.alert("password must contain at least one lowercase letter (a-z)!");
      return false;
      }
      re = /[A-Z]/;
      if(!re.test(pass)) 
      {
        window.alert("password must contain at least one uppercase letter (A-Z)!");
      return false;
      }
    }
    else 
    {
      window.alert("Please check that you've entered and confirmed your password!");
      return false;
    }
    if (pno=="" || pno==null)
       {
        window.alert("Please Enter a Phone Number");
        return false;
       }
       else if (pno.length >10)
       {
        window.alert("Phone Number must be contain Ten Numbers ");
        return false;
       }
       if (course=="" || course==null)
       {
        window.alert("Please Select Course Name");
        return false;
       }
    //alert("You entered a valid password: " + pass);
    return true;
   }
 }
 //   return true;

    
  